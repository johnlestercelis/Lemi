//
//  TableViewController.swift
//  TestLemi
//
//  Created by John Lester Celis on 03/03/2020.
//  Copyright © 2020 John Lester Celis. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

protocol TableViewControllerDelegate {
  func didSelectCity(_ selectedCity: String)
}

class TableViewController: UITableViewController {
    var delegate: TableViewControllerDelegate?
    private var searchResults = [JSON]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)
    private let apiFetcher = APIFetcher()
    private var previousRun = Date()
    private let minInterval = 0.05
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        setupTableViewBackgroundView()
        setupSearchBar()
        fetchAll()
    }
    
    private func fetchAll() {
        apiFetcher.all { (results, error) in
            if case .failure = error {
               return
           }
           
           guard let results = results, !results.isEmpty else {
               return
           }

            self.searchResults = results
        }
    }
    
    private func setupTableViewBackgroundView() {
        let backgroundViewLabel = UILabel(frame: .zero)
        backgroundViewLabel.textColor = .darkGray
        backgroundViewLabel.numberOfLines = 0
        backgroundViewLabel.text = " Oops, No results to show "
        backgroundViewLabel.textAlignment = NSTextAlignment.center
        backgroundViewLabel.font.withSize(20)
        tableView.backgroundView = backgroundViewLabel
    }

    private func setupSearchBar() {
        searchController.searchBar.delegate = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search any Topic"
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return searchResults.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? CustomTableViewCell {

            cell.titleLabel.text = searchResults[indexPath.row]["name"].stringValue
            cell.tag = indexPath.row
             cell.subtitleLabel.text = searchResults[indexPath.row]["subtitle"].string
             
             if let url = searchResults[indexPath.row]["banner"].string {
                 cell.imgView.downloadImage(from: url)
             } else {
                if let hexString = searchResults[indexPath.row]["color"].string {
                    cell.imgView.backgroundColor = UIColor(hexString: hexString)
                    cell.imageTitle.text = String(searchResults[indexPath.row]["name"].stringValue.prefix(3))
                }
            }
            cell.imgView.makeRounded()

            return cell
            
            
        }

        return UITableViewCell()
    }
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           
           let title = searchResults[indexPath.row]["name"].stringValue
            delegate?.didSelectCity(title)
        self.navigationController?.popViewController(animated: true)
           tableView.deselectRow(at: indexPath, animated: true)
       }
    

}

extension TableViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchResults.removeAll()
        guard let textToSearch = searchBar.text, !textToSearch.isEmpty else {
            return
        }
        
        if Date().timeIntervalSince(previousRun) > minInterval {
            previousRun = Date()
            fetchResults(for: textToSearch)
        }
    }
    
    func fetchResults(for text: String) {
        print("Text Searched: \(text)")
        apiFetcher.search(searchText: text, completionHandler: {
            [weak self] results, error in
            if case .failure = error {
                return
            }
            
            guard let results = results, !results.isEmpty else {
                return
            }
            
            self?.searchResults = results
        })
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        fetchAll()
    }

}
