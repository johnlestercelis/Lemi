//
//  APIFetcher.swift
//  TestLemi
//
//  Created by John Lester Celis on 3/4/20.
//  Copyright © 2020 John Lester Celis. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

enum NetworkError: Error {
    case failure
    case success
}

class APIFetcher {
    func all(completionHandler: @escaping ([JSON]?, NetworkError) -> ()) {
       let url = "https://lemi.travel/api/v5/cities"
        Alamofire.request(url).responseJSON() { response in
             if response.result.error == nil {
                 let swiftyJSON = JSON(response.value!)
                 if var result = swiftyJSON.array {
                     if result.count != 0 {
                        for (index, value) in result.enumerated() {
                            if value["type"] == "planet" {
                                result.remove(at: index)
                            }
                        }
                        completionHandler(result, .success)
                     }
                 }
             } else {
                completionHandler(nil, .failure)
             }
        }
        
    }
    
    func search(searchText: String, completionHandler: @escaping ([JSON]?, NetworkError) -> ()) {
        
        if let url = URLComponents(queryItems: [URLQueryItem(name: "q", value: searchText)]).url {
            print(url)
            Alamofire.request(url).responseJSON() { response in
               print(response.result.error.debugDescription)
                 if response.result.error == nil {
                     let swiftyJSON = JSON(response.value!)
                     if var result = swiftyJSON.array {
                         if result.count != 0 {
                            for (index, value) in result.enumerated() {
                                if value["type"] == "planet" {
                                    result.remove(at: index)
                                }
                            }
                            completionHandler(result, .success)
                         }
                     }
                 } else {
                    completionHandler(nil, .failure)
                 }
            }
        }
    }
}
